import asyncio
import math
import os
import sys
import pygame
from pygame.locals import *

if sys.platform != "emscripten":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

pygame.init()
width, height = 800, 600

pygame.display.set_caption("Pygame")
windowSurface = pygame.display.set_mode((width, height))
windowSurface.fill((55, 55, 55))

mainClock = pygame.time.Clock()

state = "menu"
level = 1
completedLevel = 0

playButton_x = width / 2 - 100
playButton_y = height / 2 - 50

introButton_scale = 1.3
introButton_w = int(round(70 * introButton_scale))
introButton_h = int(round(70 * introButton_scale))
introButton_hover_w = int(round(80 * introButton_scale))
introButton_hover_h = int(round(80 * introButton_scale))
introButton_x = width / 2 + 100
introButton_y = height / 2 + 50

homeButton_x = width - 100
homeButton_y = 20

level1Button_x = width / 2 - 40 - 200
level1Button_y = 250 - 40

level2Button_x = width / 2 - 40 - 100
level2Button_y = 250 - 40

level3Button_x = width / 2 - 40
level3Button_y = 250 - 40

level4Button_x = width / 2 - 40 + 100
level4Button_y = 250 - 40

level5Button_x = width / 2 - 40 + 200
level5Button_y = 250 - 40

returnButton_x = width / 2 - 100
returnButton_y = height / 2

chair_w, chair_h = 125, 125
chair_x, chair_y = -10, 325

obstacle1_x, obstacle1_y = 190, 75
obstacle1_active = False

g = 1
partner_angle = 0

partnerNumber = 3
enemyNumber = 20
boxNumber = 20
currentPartnerIdx = 0
stopTimer = 0

enemy_draw_offset_x = -4
enemy_draw_offset_y = -4

INACTIVE_X = 2000.0
INACTIVE_Y = 2000.0

AIM_OFFSET_X = 165.0
AIM_OFFSET_Y = 30.0


def get_aim_anchor(cur_p):
    """Return the shifted right-side pulling anchor for aiming."""
    return cur_p["x"] + AIM_OFFSET_X, cur_p["y"] + AIM_OFFSET_Y


def is_obj_spawned(o):
    """Return True if a box or enemy is spawned inside the active play area."""
    return o["x"] < 1500 and o["x"] > -500


def make_initial_objects(use_split_partners=False):
    """Create initial partner, box, and enemy objects for a level."""
    partners_init = [
        {
            "x": 35.0 if i == 0 else float(35 - i * 45),
            "y": 280.0 if i == 0 else 410.0,
            "vx": 0.0,
            "vy": 0.0,
            "type": "partner",
            "partner_kind": "split_big" if (use_split_partners and i >= 1) else "normal",
            "slot": i,
            "size": 50,
            "angle": 0.0,
            "active": i == 0,
            "shot": False,
            "gone": False,
            "has_split": False,
        }
        for i in range(partnerNumber)
    ]
    return [
        *partners_init,
        *[
            {
                "x": INACTIVE_X,
                "y": INACTIVE_Y + i * 50,
                "vx": 0.0,
                "vy": 0.0,
                "type": "box",
            }
            for i in range(boxNumber)
        ],
        *[
            {
                "x": INACTIVE_X + 100.0,
                "y": INACTIVE_Y + i * 50,
                "vx": 0.0,
                "vy": 0.0,
                "type": "enemy",
            }
            for i in range(enemyNumber)
        ],
    ]


objects = make_initial_objects()


def all_partners():
    """Return all partner objects including split small partners."""
    return [o for o in objects if o["type"] == "partner"]


def active_partners():
    """Return currently active and non-gone partner objects."""
    return [
        o
        for o in objects
        if o["type"] == "partner" and not o.get("gone") and o.get("active")
    ]


def partner():
    """Return the primary active partner object for aiming and launching."""
    act = active_partners()
    if act:
        return act[0]
    p_list = all_partners()
    if currentPartnerIdx < len(p_list):
        return p_list[currentPartnerIdx]
    return p_list[-1]


def boxes():
    """Return all box objects."""
    return [o for o in objects if o["type"] == "box"]


def enemies():
    """Return all enemy objects."""
    return [o for o in objects if o["type"] == "enemy"]


offset_x = 0

isShot = False
isAiming = False

playButton = pygame.image.load("play_button.png").convert_alpha()
playButton = pygame.transform.scale(playButton, (200, 200))

playButton_hover = pygame.image.load("play_button_hover.png").convert_alpha()
playButton_hover = pygame.transform.scale(playButton_hover, (200, 200))

introBackground = pygame.image.load("intro_background.png")
introBackground = pygame.transform.scale(introBackground, (width, height))

introButton = pygame.image.load("intro_button1.png").convert_alpha()
introButton = pygame.transform.scale(introButton, (introButton_w, introButton_h))

introButton_hover = pygame.image.load("intro_button1.png").convert_alpha()
introButton_hover = pygame.transform.scale(
    introButton_hover, (introButton_hover_w, introButton_hover_h)
)

homeButton = pygame.image.load("home_button.png").convert_alpha()
homeButton = pygame.transform.scale(homeButton, (80, 80))

homeButton_hover = pygame.image.load("home_button_hover.png").convert_alpha()
homeButton_hover = pygame.transform.scale(homeButton_hover, (80, 80))

mainMenuBackground = pygame.image.load("main_menu_background.png")
mainMenuBackground = pygame.transform.scale(mainMenuBackground, (width, height))

levelSelectionBackground = pygame.image.load("level_selection_background.png")
levelSelectionBackground = pygame.transform.scale(
    levelSelectionBackground, (width, height)
)

level1Button = pygame.image.load("level1_button.png").convert_alpha()
level1Button = pygame.transform.scale(level1Button, (80, 80))

level1Button_hover = pygame.image.load("level1_button_hover.png").convert_alpha()
level1Button_hover = pygame.transform.scale(level1Button_hover, (80, 80))

level2Button = pygame.image.load("level2_button.png").convert_alpha()
level2Button = pygame.transform.scale(level2Button, (80, 80))

level2Button_hover = pygame.image.load("level2_button_hover.png").convert_alpha()
level2Button_hover = pygame.transform.scale(level2Button_hover, (80, 80))

level3Button = pygame.image.load("level3_button.png").convert_alpha()
level3Button = pygame.transform.scale(level3Button, (80, 80))

level3Button_hover = pygame.image.load("level3_button_hover.png").convert_alpha()
level3Button_hover = pygame.transform.scale(level3Button_hover, (80, 80))

level4Button = pygame.image.load("level4_button.png").convert_alpha()
level4Button = pygame.transform.scale(level4Button, (80, 80))

level4Button_hover = pygame.image.load("level4_button_hover.png").convert_alpha()
level4Button_hover = pygame.transform.scale(level4Button_hover, (80, 80))

level5Button = pygame.image.load("level5_button.png").convert_alpha()
level5Button = pygame.transform.scale(level5Button, (80, 80))

level5Button_hover = pygame.image.load("level5_button_hover.png").convert_alpha()
level5Button_hover = pygame.transform.scale(level5Button_hover, (80, 80))

lockedButton = pygame.image.load("locked_button.png").convert_alpha()
lockedButton = pygame.transform.scale(lockedButton, (80, 80))

returnButton = pygame.image.load("again_button.png").convert_alpha()
returnButton = pygame.transform.scale(returnButton, (200, 200))

returnButton_hover = pygame.image.load("again_button_hover.png").convert_alpha()
returnButton_hover = pygame.transform.scale(returnButton_hover, (200, 200))

congratz = pygame.image.load("congratulation.png")
congratz = pygame.transform.scale(congratz, (width, height))

sky = pygame.image.load("sky.png")
sky = pygame.transform.scale(sky, (width, height))

ground = pygame.image.load("ground.png")
ground = pygame.transform.scale(ground, (width, height))

chair = pygame.image.load("chair.png").convert_alpha()
chair = pygame.transform.scale(chair, (chair_w, chair_h))

partner_img = pygame.image.load("partner.png").convert_alpha()
partner_img = pygame.transform.scale(partner_img, (50, 50))
rotated_partner = partner_img

split_partner_big_img = pygame.image.load("split_partner_big.png").convert_alpha()
split_partner_big_img = pygame.transform.scale(split_partner_big_img, (50, 50))

split_partner_small_img = pygame.image.load("split_partner_small.png").convert_alpha()
split_partner_small_img = pygame.transform.scale(split_partner_small_img, (34, 34))

enemy_img = pygame.image.load("enemy.png").convert_alpha()
enemy_img = pygame.transform.scale(enemy_img, (50, 50))

box = pygame.image.load("box.png")
box = pygame.transform.scale(box, (40, 40))

raw_obstacle1 = pygame.image.load("obstacle1.png").convert_alpha()
trim_rect = raw_obstacle1.get_bounding_rect()
if trim_rect.width > 0 and trim_rect.height > 0:
    raw_obstacle1 = raw_obstacle1.subsurface(trim_rect).copy()

orig_obs_w, orig_obs_h = raw_obstacle1.get_size()
obs_scale = min(230 / orig_obs_w, 210 / orig_obs_h)
obstacle1_w = int(round(orig_obs_w * obs_scale))
obstacle1_h = int(round(orig_obs_h * obs_scale))
obstacle1_img = pygame.transform.scale(raw_obstacle1, (obstacle1_w, obstacle1_h))
obstacle1_rect = pygame.Rect(obstacle1_x, obstacle1_y, obstacle1_w, obstacle1_h)

tree_img = pygame.image.load("tree.png").convert_alpha()
tree_img = pygame.transform.scale(tree_img, (36, 48))

intro_trees = [
    (430, 200),
    (280, 310),
    (520, 320),
    (640, 345),
    (400, 500),
    (480, 180),
]

explosion_frames = [
    pygame.transform.scale(
        pygame.image.load(f"explosion_{i}.png").convert_alpha(), (120, 120)
    )
    for i in range(1, 6)
]
explosions = []


def get_intro_button_rect():
    """Return the scaled hit rect for the intro screen button."""
    base_rect = pygame.Rect(
        int(introButton_x), int(introButton_y), introButton_w, introButton_h
    )
    scaled_w = int(round(introButton_w * introButton_scale))
    scaled_h = int(round(introButton_h * introButton_scale))
    rect = pygame.Rect(0, 0, scaled_w, scaled_h)
    rect.center = base_rect.center
    return rect


def get_partner_base_img(p_obj):
    """Return the base sprite image for a partner object."""
    kind = p_obj.get("partner_kind", "normal")
    if kind == "split_big":
        return split_partner_big_img
    elif kind == "split_small":
        return split_partner_small_img
    return partner_img


def trigger_split_partner():
    """Split an active split_big partner into two split_small partners."""
    act_list = active_partners()
    if len(act_list) != 1:
        return False

    big_p = act_list[0]
    if big_p.get("partner_kind") != "split_big" or big_p.get("has_split"):
        return False

    bx, by = big_p["x"], big_p["y"]
    vx, vy = big_p["vx"], big_p["vy"]
    slot = big_p.get("slot", currentPartnerIdx)

    big_p["has_split"] = True
    big_p["gone"] = True
    big_p["active"] = False
    big_p["x"] = -2000.0
    big_p["y"] = -2000.0
    big_p["vx"] = 0.0
    big_p["vy"] = 0.0

    small_1 = {
        "x": bx + 8.0,
        "y": by - 14.0,
        "vx": vx * 1.05,
        "vy": vy - 4.5,
        "type": "partner",
        "partner_kind": "split_small",
        "slot": slot,
        "size": 34,
        "angle": big_p.get("angle", 0.0),
        "active": True,
        "shot": True,
        "gone": False,
        "has_split": True,
    }
    small_2 = {
        "x": bx + 8.0,
        "y": by + 18.0,
        "vx": vx * 1.05,
        "vy": vy + 3.5,
        "type": "partner",
        "partner_kind": "split_small",
        "slot": slot,
        "size": 34,
        "angle": big_p.get("angle", 0.0),
        "active": True,
        "shot": True,
        "gone": False,
        "has_split": True,
    }
    objects.insert(0, small_1)
    objects.insert(1, small_2)
    return True


def enemyDie(o):
    """Spawn an explosion at the enemy position and move it to inactive area."""
    explosions.append({"x": o["x"], "y": o["y"], "frame": 0})
    o["x"] = INACTIVE_X + 100.0
    o["y"] = INACTIVE_Y
    o["vx"] = 0.0
    o["vy"] = 0.0


def resolve_obstacle1_collision(o, obj_w, obj_h):
    """Resolve collision and bounce response between an object and obstacle1_rect."""
    if not obstacle1_active:
        return

    obj_rect = pygame.Rect(o["x"], o["y"], obj_w, obj_h)
    if not obj_rect.colliderect(obstacle1_rect):
        return

    overlap_left = obj_rect.right - obstacle1_rect.left
    overlap_right = obstacle1_rect.right - obj_rect.left
    overlap_top = obj_rect.bottom - obstacle1_rect.top
    overlap_bottom = obstacle1_rect.bottom - obj_rect.top

    min_overlap = min(overlap_left, overlap_right, overlap_top, overlap_bottom)

    if min_overlap == overlap_left:
        o["x"] = float(obstacle1_rect.left - obj_w)
        if o["vx"] > 0:
            o["vx"] *= -0.55
    elif min_overlap == overlap_right:
        o["x"] = float(obstacle1_rect.right)
        if o["vx"] < 0:
            o["vx"] *= -0.55
    elif min_overlap == overlap_top:
        o["y"] = float(obstacle1_rect.top - obj_h)
        if o["vy"] > 0:
            o["vy"] *= -0.45
        o["vx"] *= 0.88
    else:
        o["y"] = float(obstacle1_rect.bottom)
        if o["vy"] < 0:
            o["vy"] *= -0.45


def clamp_to_side_walls():
    """Keep active objects inside horizontal boundaries and resolve obstacle1 collisions."""
    for o in objects:
        if o["type"] == "partner":
            if o.get("gone") or not o.get("active"):
                continue
            p_size = o.get("size", 50)
            obj_w, obj_h = p_size, p_size
            left_limit = -9999
        elif o["type"] == "enemy":
            if not is_obj_spawned(o):
                continue
            obj_w, obj_h = 50, 50
            left_limit = 220
        else:
            if not is_obj_spawned(o):
                continue
            obj_w, obj_h = 40, 40
            left_limit = 220

        right_limit = width - obj_w
        if o["x"] < left_limit:
            o["x"] = left_limit
            if o["vx"] < 0:
                o["vx"] *= -0.4
        elif o["x"] > right_limit:
            o["x"] = right_limit
            if o["vx"] > 0:
                o["vx"] *= -0.4

        resolve_obstacle1_collision(o, obj_w, obj_h)


def reset(use_split_partners=False):
    """Reset objects, partner queue, and aiming/shot state for the current level."""
    global state, partner_angle, objects, offset_x, isShot, isAiming, currentPartnerIdx, stopTimer, obstacle1_active
    partner_angle = 0
    currentPartnerIdx = 0
    stopTimer = 0
    obstacle1_active = False

    objects = make_initial_objects(use_split_partners=use_split_partners)

    offset_x = 0

    isShot = False
    isAiming = False


def level1():
    """Configure level 1 layout."""
    reset(use_split_partners=False)
    i = 0
    for o in objects:
        if o["type"] == "box" and i < 5:
            o["x"] = 600
            o["y"] = -i * 50
            i += 1

    enemies()[0]["x"] = 600
    enemies()[0]["y"] = -300


def level2():
    """Configure level 2 layout with obstacle1 and split partners."""
    global obstacle1_active
    reset(use_split_partners=True)
    obstacle1_active = True

    for i in range(1):
        boxes()[i]["y"] = -i * 50
        boxes()[i]["x"] = 500
        i += 1
    for i in range(1, 4):
        boxes()[i]["y"] = -i * 50
        boxes()[i]["x"] = 600
        i += 1
    for i in range(4, 9):
        boxes()[i]["y"] = -i * 50
        boxes()[i]["x"] = 700
        i += 1
    enemies()[0]["x"] = 500
    enemies()[0]["y"] = -200
    enemies()[1]["x"] = 600
    enemies()[1]["y"] = -350
    enemies()[2]["x"] = 700
    enemies()[2]["y"] = -500


def level3():
    """Configure level 3 layout."""
    reset(use_split_partners=False)
    i = 0
    for o in objects:
        if o["type"] == "box" and i < 3:
            o["x"] = 550 + i * 40
            o["y"] = -i * 50
            i += 1

    boxes()[3]["x"] = 550
    boxes()[3]["y"] = -150
    enemies()[0]["x"] = 590
    enemies()[0]["y"] = -200
    boxes()[4]["x"] = 630
    boxes()[4]["y"] = -250

    boxes()[5]["x"] = 550
    boxes()[5]["y"] = -200
    boxes()[6]["x"] = 590
    boxes()[6]["y"] = -280
    boxes()[7]["x"] = 630
    boxes()[7]["y"] = -300


def level4():
    """Configure level 4 layout."""
    reset(use_split_partners=False)
    i = 0
    for o in objects:
        if o["type"] == "box" and i < 8:
            o["x"] = 400
            o["y"] = -i * 50
            i += 1
    j = 0
    for o in objects:
        if o["type"] == "box" and j < 3:
            o["x"] = 550 + j * 40
            o["y"] = -j * 50
            j += 1

    boxes()[11]["x"] = 550
    boxes()[11]["y"] = -150
    enemies()[0]["x"] = 590
    enemies()[0]["y"] = -200
    boxes()[12]["x"] = 630
    boxes()[12]["y"] = -250

    boxes()[13]["x"] = 550
    boxes()[13]["y"] = -200
    boxes()[14]["x"] = 590
    boxes()[14]["y"] = -280
    boxes()[15]["x"] = 630
    boxes()[7]["y"] = -300


def level5():
    """Configure level 5 layout."""
    reset(use_split_partners=False)
    i = 0
    for o in objects:
        if o["type"] == "box" and i < 5:
            o["x"] = 500
            o["y"] = -i * 50
            i += 1

    boxes()[5]["x"] = 400
    boxes()[5]["y"] = -100
    boxes()[6]["x"] = 600
    boxes()[6]["y"] = -100
    enemies()[0]["x"] = 600
    enemies()[0]["y"] = -200
    enemies()[1]["x"] = 500
    enemies()[1]["y"] = -300
    enemies()[2]["x"] = 400
    enemies()[2]["y"] = -300


def draw_top_right_home_button(mx, my):
    """Draw the top-right navigation button and return whether the cursor is over it."""
    dx = mx - homeButton_x - 40
    dy = my - homeButton_y - 40
    d = math.sqrt(dx**2 + dy**2)
    if d < 40:
        windowSurface.blit(homeButton_hover, (homeButton_x, homeButton_y))
    else:
        windowSurface.blit(homeButton, (homeButton_x, homeButton_y))
    return d < 40


def quit_game():
    """Quit pygame safely without calling sys.exit() under emscripten."""
    pygame.quit()
    if sys.platform != "emscripten":
        sys.exit()


async def main():
    """Main asynchronous game loop compatible with pygbag."""
    global state, level, completedLevel, partner_angle, objects, offset_x
    global isShot, isAiming, currentPartnerIdx, stopTimer, obstacle1_active
    global explosions

    while True:
        if level == 1:
            level1()
        elif level == 2:
            level2()
        elif level == 3:
            level3()
        elif level == 4:
            level4()
        elif level == 5:
            level5()
        elif level > 5:
            windowSurface.blit(congratz, (0, 0))
            mx, my = pygame.mouse.get_pos()

            for event in pygame.event.get():
                if event.type == QUIT:
                    quit_game()
                    return

                if event.type == MOUSEBUTTONUP:
                    dx = mx - returnButton_x - 100
                    dy = my - returnButton_y - 100
                    d = math.sqrt(dx**2 + dy**2)
                    if d < 100 and event.button == 1:
                        level = 1
                        state = "menu"
                        break

            dx = mx - returnButton_x - 100
            dy = my - returnButton_y - 100
            d = math.sqrt(dx**2 + dy**2)
            if d < 100:
                windowSurface.blit(returnButton_hover, (returnButton_x, returnButton_y))
            else:
                windowSurface.blit(returnButton, (returnButton_x, returnButton_y))

            pygame.display.update()
            mainClock.tick(60)
            await asyncio.sleep(0)
            continue

        ButtonClicked = False
        if state != "win":
            while True:
                for event in pygame.event.get():
                    if event.type == QUIT:
                        quit_game()
                        return

                    if state == "menu":
                        if event.type == MOUSEBUTTONUP:
                            mx, my = pygame.mouse.get_pos()
                            dx = mx - playButton_x - 100
                            dy = my - playButton_y - 100
                            d = math.sqrt(dx**2 + dy**2)
                            if d < 100 and event.button == 1:
                                state = "intro"

                    elif state == "intro":
                        if event.type == MOUSEBUTTONUP and event.button == 1:
                            mx, my = pygame.mouse.get_pos()
                            hx = mx - homeButton_x - 40
                            hy = my - homeButton_y - 40
                            if math.sqrt(hx**2 + hy**2) < 40:
                                state = "menu"
                                continue

                            if get_intro_button_rect().collidepoint(mx, my):
                                state = "selecting"

                    elif state == "selecting":
                        if event.type == MOUSEBUTTONUP and event.button == 1:
                            mx, my = pygame.mouse.get_pos()
                            hx = mx - homeButton_x - 40
                            hy = my - homeButton_y - 40
                            if math.sqrt(hx**2 + hy**2) < 40:
                                state = "intro"
                                continue

                            dx1 = mx - level1Button_x - 40
                            dy1 = my - level1Button_y - 40
                            if math.sqrt(dx1**2 + dy1**2) < 40:
                                level = 1
                                state = "playing"
                                ButtonClicked = True
                                break

                            dx2 = mx - level2Button_x - 40
                            dy2 = my - level2Button_y - 40
                            if math.sqrt(dx2**2 + dy2**2) < 40 and completedLevel >= 1:
                                level = 2
                                state = "playing"
                                ButtonClicked = True
                                break

                            dx3 = mx - level3Button_x - 40
                            dy3 = my - level3Button_y - 40
                            if math.sqrt(dx3**2 + dy3**2) < 40 and completedLevel >= 2:
                                level = 3
                                state = "playing"
                                ButtonClicked = True
                                break

                            dx4 = mx - level4Button_x - 40
                            dy4 = my - level4Button_y - 40
                            if math.sqrt(dx4**2 + dy4**2) < 40 and completedLevel >= 3:
                                level = 4
                                state = "playing"
                                ButtonClicked = True
                                break

                            dx5 = mx - level5Button_x - 40
                            dy5 = my - level5Button_y - 40
                            if math.sqrt(dx5**2 + dy5**2) < 40 and completedLevel >= 4:
                                level = 5
                                state = "playing"
                                ButtonClicked = True
                                break

                    elif state == "playing":
                        if event.type == MOUSEBUTTONDOWN:
                            if event.button == 1:
                                mx, my = pygame.mouse.get_pos()
                                dx = mx - homeButton_x - 50
                                dy = my - homeButton_y - 50
                                if math.sqrt(dx**2 + dy**2) < 50:
                                    state = "menu"
                                    ButtonClicked = True
                                    break
                                elif isShot:
                                    trigger_split_partner()
                                elif currentPartnerIdx < partnerNumber:
                                    isAiming = True

                        if event.type == MOUSEBUTTONUP:
                            if event.button == 1 and isAiming:
                                mx, my = pygame.mouse.get_pos()
                                cur_p = partner()
                                aim_x, aim_y = get_aim_anchor(cur_p)
                                cur_p["vx"] = ((aim_x - mx) / 4.0) * 1.35
                                cur_p["vy"] = ((aim_y - my) / 4.0) * 1.2

                                cur_p["shot"] = True
                                isShot = True
                                isAiming = False
                                stopTimer = 0

                if ButtonClicked:
                    break

                if state == "playing":
                    offset_x = 0

                    if all(not is_obj_spawned(o) for o in objects if o["type"] == "enemy"):
                        if level > completedLevel:
                            completedLevel = level
                        level += 1
                        break

                    if currentPartnerIdx >= partnerNumber:
                        ButtonClicked = True
                        break

                    if not isShot:
                        cur_p = partner()
                        cur_p["x"] = 35.0
                        cur_p["y"] = 280.0
                        cur_p["angle"] = 0.0
                        partner_angle = 0
                    else:
                        for p_obj in active_partners():
                            p_obj["vy"] += g
                            p_obj["x"] += p_obj["vx"]
                            p_obj["y"] += p_obj["vy"]
                            p_obj["angle"] = p_obj.get("angle", 0.0) - p_obj["vx"]
                        if active_partners():
                            partner_angle = active_partners()[0].get("angle", 0.0)

                    for o in objects:
                        if o["type"] != "partner" and is_obj_spawned(o):
                            o["vy"] += g
                            o["x"] += o["vx"]
                            o["y"] += o["vy"]

                    clamp_to_side_walls()

                    for _ in range(8):
                        for i in range(len(objects)):
                            for j in range(i + 1, len(objects)):
                                a = objects[i]
                                b = objects[j]

                                if a["type"] == "partner" and (
                                    a.get("gone") or not a.get("active")
                                ):
                                    continue
                                if b["type"] == "partner" and (
                                    b.get("gone") or not b.get("active")
                                ):
                                    continue

                                if (
                                    a["type"] == "partner"
                                    and b["type"] == "partner"
                                    and a.get("partner_kind") == "split_small"
                                    and b.get("partner_kind") == "split_small"
                                ):
                                    continue

                                if a["type"] != "partner" and not is_obj_spawned(a):
                                    continue
                                if b["type"] != "partner" and not is_obj_spawned(b):
                                    continue

                                ra = (
                                    (a.get("size", 50) * 0.42)
                                    if a["type"] == "partner"
                                    else 20.0
                                )
                                rb = (
                                    (b.get("size", 50) * 0.42)
                                    if b["type"] == "partner"
                                    else 20.0
                                )
                                min_dist = ra + rb

                                ca_x = a["x"] + (
                                    a.get("size", 50) * 0.5
                                    if a["type"] == "partner"
                                    else 20.0
                                )
                                ca_y = a["y"] + (
                                    a.get("size", 50) * 0.5
                                    if a["type"] == "partner"
                                    else 20.0
                                )
                                cb_x = b["x"] + (
                                    b.get("size", 50) * 0.5
                                    if b["type"] == "partner"
                                    else 20.0
                                )
                                cb_y = b["y"] + (
                                    b.get("size", 50) * 0.5
                                    if b["type"] == "partner"
                                    else 20.0
                                )

                                dx = cb_x - ca_x
                                dy = cb_y - ca_y
                                dist_sq = dx**2 + dy**2

                                if dist_sq == 0 or dist_sq >= min_dist**2:
                                    continue

                                dist = math.sqrt(dist_sq)
                                nx = dx / dist
                                ny = dy / dist
                                overlap = (min_dist - dist) + 0.5

                                if a["type"] == "partner" and b["type"] != "partner":
                                    b["x"] += nx * overlap
                                    b["y"] += ny * overlap
                                elif b["type"] == "partner" and a["type"] != "partner":
                                    a["x"] -= nx * overlap
                                    a["y"] -= ny * overlap
                                else:
                                    a["x"] -= nx * overlap * 0.5
                                    a["y"] -= ny * overlap * 0.5
                                    b["x"] += nx * overlap * 0.5
                                    b["y"] += ny * overlap * 0.5

                                va_n = a["vx"] * nx + a["vy"] * ny
                                vb_n = b["vx"] * nx + b["vy"] * ny

                                if va_n - vb_n > 0:
                                    if a["type"] == "partner" and b["type"] != "partner":
                                        a["vx"] += (vb_n - va_n) * nx * 0.35
                                        a["vy"] += (vb_n - va_n) * ny * 0.35
                                        b["vx"] += (va_n - vb_n) * nx * 1.15
                                        b["vy"] += (va_n - vb_n) * ny * 1.15
                                    elif b["type"] == "partner" and a["type"] != "partner":
                                        a["vx"] += (vb_n - va_n) * nx * 1.15
                                        a["vy"] += (vb_n - va_n) * ny * 1.15
                                        b["vx"] += (va_n - vb_n) * nx * 0.35
                                        b["vy"] += (va_n - vb_n) * ny * 0.35
                                    else:
                                        a["vx"] += (vb_n - va_n) * nx
                                        a["vy"] += (vb_n - va_n) * ny
                                        b["vx"] += (va_n - vb_n) * nx
                                        b["vy"] += (va_n - vb_n) * ny

                        clamp_to_side_walls()

                    act_p_list = active_partners()
                    for o in objects:
                        if o["type"] == "enemy" and is_obj_spawned(o):
                            for p_obj in act_p_list:
                                p_half = p_obj.get("size", 50) * 0.5
                                hit_r = p_half + 23.0
                                dx = (p_obj["x"] + p_half) - (o["x"] + 25)
                                dy = (p_obj["y"] + p_half) - (o["y"] + 25)
                                if math.hypot(dx, dy) < hit_r:
                                    enemyDie(o)
                                    break

                            if is_obj_spawned(o) and o["y"] >= 410 and o["vy"] > 8:
                                enemyDie(o)

                    for o in objects:
                        if o["type"] == "partner":
                            if o.get("gone") or not o.get("active"):
                                continue
                            ground_limit = 460 - o.get("size", 50)
                        elif not is_obj_spawned(o):
                            continue
                        else:
                            ground_limit = 410

                        if o["y"] > ground_limit:
                            o["y"] = ground_limit
                            o["vy"] = 0
                            o["vx"] *= 0.95

                    clamp_to_side_walls()

                    if isShot and currentPartnerIdx < partnerNumber:
                        act_p_list = active_partners()
                        all_ready_to_despawn = True

                        for p_obj in act_p_list:
                            speed = math.hypot(p_obj["vx"], p_obj["vy"])
                            out_of_screen = (
                                p_obj["x"] < -150
                                or p_obj["x"] > width + 150
                                or p_obj["y"] > height + 150
                            )
                            is_stopped = speed < 0.4
                            if not (is_stopped or out_of_screen):
                                all_ready_to_despawn = False
                                break

                        if all_ready_to_despawn:
                            stopTimer += 1
                        else:
                            stopTimer = 0

                        if stopTimer >= 10:
                            for p_obj in act_p_list:
                                p_obj["gone"] = True
                                p_obj["active"] = False
                                p_obj["x"] = -2000.0
                                p_obj["y"] = -2000.0
                                p_obj["vx"] = 0.0
                                p_obj["vy"] = 0.0

                            currentPartnerIdx += 1
                            stopTimer = 0
                            isShot = False
                            isAiming = False
                            partner_angle = 0

                            next_candidates = [
                                p_obj
                                for p_obj in all_partners()
                                if not p_obj.get("gone")
                                and p_obj.get("slot") == currentPartnerIdx
                            ]
                            if next_candidates:
                                next_p = next_candidates[0]
                                next_p["active"] = True
                                next_p["x"] = 35.0
                                next_p["y"] = 280.0
                                next_p["angle"] = 0.0

                    for e in explosions:
                        e["frame"] += 0.3
                    explosions = [
                        e for e in explosions if e["frame"] < len(explosion_frames)
                    ]

                if state == "menu":
                    windowSurface.blit(mainMenuBackground, (0, 0))
                    mx, my = pygame.mouse.get_pos()
                    dx = mx - playButton_x - 100
                    dy = my - playButton_y - 100
                    if math.sqrt(dx**2 + dy**2) < 100:
                        windowSurface.blit(playButton_hover, (playButton_x, playButton_y))
                    else:
                        windowSurface.blit(playButton, (playButton_x, playButton_y))

                elif state == "intro":
                    windowSurface.blit(introBackground, (0, 0))
                    for tx, ty in intro_trees:
                        windowSurface.blit(tree_img, (tx, ty))

                    mx, my = pygame.mouse.get_pos()
                    intro_rect = get_intro_button_rect()
                    if intro_rect.collidepoint(mx, my):
                        hover_rect = introButton_hover.get_rect(center=intro_rect.center)
                        windowSurface.blit(introButton_hover, hover_rect.topleft)
                    else:
                        draw_rect = introButton.get_rect(center=intro_rect.center)
                        windowSurface.blit(introButton, draw_rect.topleft)

                    draw_top_right_home_button(mx, my)

                elif state == "selecting":
                    windowSurface.blit(levelSelectionBackground, (0, 0))
                    mx, my = pygame.mouse.get_pos()
                    draw_top_right_home_button(mx, my)

                    dx1 = mx - level1Button_x - 40
                    dy1 = my - level1Button_y - 40
                    if math.sqrt(dx1**2 + dy1**2) < 40:
                        windowSurface.blit(
                            level1Button_hover, (level1Button_x, level1Button_y)
                        )
                    else:
                        windowSurface.blit(
                            level1Button, (level1Button_x, level1Button_y)
                        )

                    dx2 = mx - level2Button_x - 40
                    dy2 = my - level2Button_y - 40
                    if completedLevel >= 1:
                        if math.sqrt(dx2**2 + dy2**2) < 40:
                            windowSurface.blit(
                                level2Button_hover, (level2Button_x, level2Button_y)
                            )
                        else:
                            windowSurface.blit(
                                level2Button, (level2Button_x, level2Button_y)
                            )
                    else:
                        windowSurface.blit(
                            lockedButton, (level2Button_x, level2Button_y)
                        )

                    dx3 = mx - level3Button_x - 40
                    dy3 = my - level3Button_y - 40
                    if completedLevel >= 2:
                        if math.sqrt(dx3**2 + dy3**2) < 40:
                            windowSurface.blit(
                                level3Button_hover, (level3Button_x, level3Button_y)
                            )
                        else:
                            windowSurface.blit(
                                level3Button, (level3Button_x, level3Button_y)
                            )
                    else:
                        windowSurface.blit(
                            lockedButton, (level3Button_x, level3Button_y)
                        )

                    dx4 = mx - level4Button_x - 40
                    dy4 = my - level4Button_y - 40
                    if completedLevel >= 3:
                        if math.sqrt(dx4**2 + dy4**2) < 40:
                            windowSurface.blit(
                                level4Button_hover, (level4Button_x, level4Button_y)
                            )
                        else:
                            windowSurface.blit(
                                level4Button, (level4Button_x, level4Button_y)
                            )
                    else:
                        windowSurface.blit(
                            lockedButton, (level4Button_x, level4Button_y)
                        )

                    dx5 = mx - level5Button_x - 40
                    dy5 = my - level5Button_y - 40
                    if completedLevel >= 4:
                        if math.sqrt(dx5**2 + dy5**2) < 40:
                            windowSurface.blit(
                                level5Button_hover, (level5Button_x, level5Button_y)
                            )
                        else:
                            windowSurface.blit(
                                level5Button, (level5Button_x, level5Button_y)
                            )
                    else:
                        windowSurface.blit(
                            lockedButton, (level5Button_x, level5Button_y)
                        )

                elif state == "playing":
                    windowSurface.fill((55, 55, 55))

                    for i in range(10):
                        windowSurface.blit(sky, (i * width, 0))

                    for i in range(10):
                        windowSurface.blit(ground, (i * width, 450))
                    windowSurface.blit(chair, (chair_x, chair_y))

                    if obstacle1_active:
                        windowSurface.blit(obstacle1_img, obstacle1_rect.topleft)

                    for o in objects:
                        if not is_obj_spawned(o):
                            continue
                        if o["type"] == "box":
                            windowSurface.blit(box, (o["x"], o["y"]))
                        elif o["type"] == "enemy":
                            windowSurface.blit(
                                enemy_img,
                                (
                                    o["x"] + enemy_draw_offset_x,
                                    o["y"] + enemy_draw_offset_y,
                                ),
                            )

                    if isAiming and currentPartnerIdx < partnerNumber:
                        mx, my = pygame.mouse.get_pos()
                        cur_p = partner()
                        aim_x, aim_y = get_aim_anchor(cur_p)
                        vx, vy = aim_x - mx, aim_y - my
                        bx, by = cur_p["x"] + 20, cur_p["y"] + 20

                        n = 5
                        for i in range(n):
                            pygame.draw.circle(
                                windowSurface,
                                (255, 255, 255),
                                (bx + vx / n * (i + 1), by + vy / n * (i + 1)),
                                5,
                            )

                    for p_obj in all_partners():
                        if p_obj.get("gone"):
                            continue
                        base_img = get_partner_base_img(p_obj)
                        p_half = p_obj.get("size", 50) * 0.5
                        if p_obj.get("active"):
                            rot_img = pygame.transform.rotate(
                                base_img, p_obj.get("angle", 0.0)
                            )
                            rect = rot_img.get_rect(
                                center=(p_obj["x"] + p_half, p_obj["y"] + p_half)
                            )
                            windowSurface.blit(rot_img, rect.topleft)
                        else:
                            windowSurface.blit(base_img, (p_obj["x"], p_obj["y"]))

                    for e in explosions:
                        frame_img = explosion_frames[int(e["frame"])]
                        windowSurface.blit(frame_img, (e["x"] - 40, e["y"] - 40))

                    mx, my = pygame.mouse.get_pos()
                    draw_top_right_home_button(mx, my)

                pygame.display.update()
                mainClock.tick(60)
                await asyncio.sleep(0)

        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())